@extends('layouts.main')

@section('container')
  <h1>Home Page</h1>
@endsection

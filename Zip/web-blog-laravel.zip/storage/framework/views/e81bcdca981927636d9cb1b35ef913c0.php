



<?php $__env->startSection('container'); ?>
    

    <article class="mb-5">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h2>
                <a href="/posts/<?php echo e($post["slug"]); ?>"><?php echo e($post["title"]); ?></a>
            </h2>
            <h5>By : <?php echo e($post["author"]); ?></h5>
            <p><?php echo e($post["body"]); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </article>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DevProjects\Web\WithFrameworks\magang-web-laravel\web-blog-laravel\resources\views/posts.blade.php ENDPATH**/ ?>
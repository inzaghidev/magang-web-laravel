

<?php $__env->startSection('container'); ?>
    <h1>About Page</h1>
    <h3><?php echo e($name); ?></h3>
    <h5><?php echo e($email); ?></h5>
    <img src="img/<?php echo e($image); ?>" alt="<?php echo e($name); ?>" width="200">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DevProjects\Web\WithFrameworks\magang-web-laravel\web-blog-laravel\resources\views/about.blade.php ENDPATH**/ ?>